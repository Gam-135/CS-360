package com.example.inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editQuantity;
    private Button buttonAdd;
    private Button buttonSendSms;
    private Button buttonLogout;
    private RecyclerView recyclerViewItems;
    private AppDatabase db;
    private InventoryAdapter adapter;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    sendSmsAlert();
                } else {
                    Toast.makeText(this, "SMS permission denied. The app will still work without text alerts.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSendSms = findViewById(R.id.buttonSendSms);
        buttonLogout = findViewById(R.id.buttonLogout);
        recyclerViewItems = findViewById(R.id.recyclerViewItems);

        // Create the Room database used for inventory records
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "inventory_database")
                .allowMainThreadQueries()
                .build();

        // Display all inventory items in a two-column grid
        recyclerViewItems.setLayoutManager(new GridLayoutManager(this, 2));
        loadItems();

        // Add a new item to the database
        buttonAdd.setOnClickListener(v -> {
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Please enter an item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);
            db.inventoryItemDao().insert(new InventoryItem(itemName, quantity));

            editItemName.setText("");
            editQuantity.setText("");
            loadItems();
        });

        // Request SMS permission only when the user wants to send an alert
        buttonSendSms.setOnClickListener(v -> requestSmsPermission());

        buttonLogout.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, MainActivity.class);

            // Prevent going back to inventory screen
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(intent);
            finish();
        });
    }

    // Read all items from the database and display them in the grid
    private void loadItems() {
        List<InventoryItem> itemList = db.inventoryItemDao().getAllItems();
        adapter = new InventoryAdapter(itemList, db, this::loadItems);
        recyclerViewItems.setAdapter(adapter);
    }

    // Ask for SMS permission at runtime
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSmsAlert();
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    // Send an inventory text alert if permission has been granted
    private void sendSmsAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("1234567890", null,
                    "Inventory alert: Please review low stock items.", null, null);
            Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Unable to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}