package com.example.inventoryapp;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private final List<InventoryItem> itemList;
    private final AppDatabase db;
    private final Runnable refreshCallback;

    public InventoryAdapter(List<InventoryItem> itemList, AppDatabase db, Runnable refreshCallback) {
        this.itemList = itemList;
        this.db = db;
        this.refreshCallback = refreshCallback;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.textItemName.setText(item.itemName);
        holder.textQuantity.setText("Quantity: " + item.quantity);

        holder.buttonDelete.setOnClickListener(v -> {
            db.inventoryItemDao().delete(item);
            refreshCallback.run();
        });

        holder.buttonUpdate.setOnClickListener(v -> showUpdateDialog(v, item));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    private void showUpdateDialog(View view, InventoryItem item) {
        View dialogView = LayoutInflater.from(view.getContext()).inflate(R.layout.dialog_update_inventory, null);

        EditText dialogEditItemName = dialogView.findViewById(R.id.dialogEditItemName);
        EditText dialogEditQuantity = dialogView.findViewById(R.id.dialogEditQuantity);

        dialogEditItemName.setText(item.itemName);
        dialogEditQuantity.setText(String.valueOf(item.quantity));

        new AlertDialog.Builder(view.getContext())
                .setTitle("Update Item")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String updatedName = dialogEditItemName.getText().toString().trim();
                    String updatedQuantityText = dialogEditQuantity.getText().toString().trim();

                    if (!updatedName.isEmpty() && !updatedQuantityText.isEmpty()) {
                        item.itemName = updatedName;
                        item.quantity = Integer.parseInt(updatedQuantityText);
                        db.inventoryItemDao().update(item);
                        refreshCallback.run();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView textItemName;
        TextView textQuantity;
        Button buttonUpdate;
        Button buttonDelete;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemName = itemView.findViewById(R.id.textItemName);
            textQuantity = itemView.findViewById(R.id.textQuantity);
            buttonUpdate = itemView.findViewById(R.id.buttonUpdate);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}